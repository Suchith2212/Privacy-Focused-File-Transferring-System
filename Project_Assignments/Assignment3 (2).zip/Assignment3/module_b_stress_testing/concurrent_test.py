"""Compatibility entrypoint for concurrent test naming in rubric checklists."""

from __future__ import annotations

from .concurrent_vault_test import main


if __name__ == "__main__":
    main()
