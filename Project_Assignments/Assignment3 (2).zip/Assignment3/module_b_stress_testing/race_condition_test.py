"""Compatibility entrypoint for race condition test naming in rubric checklists."""

from __future__ import annotations

from .race_condition_download_test import main


if __name__ == "__main__":
    main()
