CREATE DATABASE IF NOT EXISTS blinddrop_proto;
USE blinddrop_proto;

CREATE TABLE IF NOT EXISTS vaults (
  vault_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  outer_token VARCHAR(32) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP NOT NULL,
  status ENUM('ACTIVE', 'EXPIRED', 'DELETED') NOT NULL DEFAULT 'ACTIVE',
  CHECK (expires_at > created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inner_tokens (
  inner_token_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  vault_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  token_type ENUM('MAIN', 'SUB') NOT NULL,
  token_hash CHAR(64) NOT NULL,
  token_lookup_hash CHAR(64) NULL,
  salt CHAR(32) NOT NULL,
  key_iterations INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('ACTIVE', 'REVOKED') NOT NULL DEFAULT 'ACTIVE',
  CONSTRAINT fk_inner_tokens_vault
    FOREIGN KEY (vault_id) REFERENCES vaults(vault_id) ON DELETE CASCADE,
  INDEX idx_inner_tokens_vault_status (vault_id, status),
  INDEX idx_inner_tokens_lookup_hash (token_lookup_hash, vault_id, status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS files (
  file_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  vault_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  drive_file_id VARCHAR(128) NOT NULL UNIQUE,
  original_filename VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size BIGINT NOT NULL,
  storage_path TEXT NULL,
  file_key_iv CHAR(32) NULL,
  file_hmac CHAR(64) NULL,
  status ENUM('ACTIVE', 'DELETED') NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP NULL,
  CONSTRAINT fk_files_vault
    FOREIGN KEY (vault_id) REFERENCES vaults(vault_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS file_metadata (
  metadata_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  file_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  relative_path VARCHAR(512) NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size BIGINT NOT NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_file_metadata_file
    FOREIGN KEY (file_id) REFERENCES files(file_id) ON DELETE CASCADE,
  UNIQUE KEY uq_file_metadata_file (file_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS file_key_access (
  access_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  file_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  inner_token_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  encrypted_file_key CHAR(64) NULL,
  CONSTRAINT fk_file_access_file
    FOREIGN KEY (file_id) REFERENCES files(file_id) ON DELETE CASCADE,
  CONSTRAINT fk_file_access_token
    FOREIGN KEY (inner_token_id) REFERENCES inner_tokens(inner_token_id) ON DELETE CASCADE,
  UNIQUE KEY uq_file_token_access (file_id, inner_token_id),
  INDEX idx_file_key_access_token (inner_token_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sessions (
  session_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  ip_address VARCHAR(45) NOT NULL,
  user_agent TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_activity TIMESTAMP NULL,
  INDEX idx_sessions_ip_created (ip_address, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS auth_attempts (
  attempt_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  session_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  vault_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  attempt_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  success BOOLEAN NOT NULL,
  CONSTRAINT fk_auth_attempts_session
    FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE,
  CONSTRAINT fk_auth_attempts_vault
    FOREIGN KEY (vault_id) REFERENCES vaults(vault_id) ON DELETE CASCADE,
  INDEX idx_auth_attempts_time (attempt_time),
  INDEX idx_auth_attempts_vault_time (vault_id, attempt_time),
  INDEX idx_auth_attempts_session_time (session_id, attempt_time, success)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS download_logs (
  download_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  file_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  inner_token_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  session_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
  download_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_download_file
    FOREIGN KEY (file_id) REFERENCES files(file_id) ON DELETE CASCADE,
  CONSTRAINT fk_download_token
    FOREIGN KEY (inner_token_id) REFERENCES inner_tokens(inner_token_id) ON DELETE CASCADE,
  CONSTRAINT fk_download_session
    FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE SET NULL,
  INDEX idx_download_time (download_time),
  INDEX idx_download_file_time (file_id, download_time),
  INDEX idx_download_token (inner_token_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS captcha_tracking (
  captcha_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  session_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  attempts INT NOT NULL DEFAULT 0,
  required BOOLEAN NOT NULL DEFAULT FALSE,
  last_attempt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_captcha_tracking_session
    FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE,
  UNIQUE KEY uq_captcha_session (session_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS expiry_jobs (
  job_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  vault_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  scheduled_time TIMESTAMP NOT NULL,
  processed BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_expiry_jobs_vault
    FOREIGN KEY (vault_id) REFERENCES vaults(vault_id) ON DELETE CASCADE,
  UNIQUE KEY uq_expiry_job_vault (vault_id),
  INDEX idx_expiry_jobs_sched (processed, scheduled_time)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS portfolio_entries (
  entry_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  vault_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  owner_token_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  created_by_token_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  title VARCHAR(120) NOT NULL,
  content TEXT NOT NULL,
  integrity_hash CHAR(64) NOT NULL,
  status ENUM('ACTIVE', 'DELETED') NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_portfolio_vault
    FOREIGN KEY (vault_id) REFERENCES vaults(vault_id) ON DELETE CASCADE,
  CONSTRAINT fk_portfolio_owner_token
    FOREIGN KEY (owner_token_id) REFERENCES inner_tokens(inner_token_id) ON DELETE CASCADE,
  CONSTRAINT fk_portfolio_created_by_token
    FOREIGN KEY (created_by_token_id) REFERENCES inner_tokens(inner_token_id) ON DELETE CASCADE,
  INDEX idx_portfolio_integrity_hash (integrity_hash)
) ENGINE=InnoDB;

SET @sql = IF(
  EXISTS(
    SELECT 1
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'vaults'
      AND index_name = 'idx_vault_expiry'
  ),
  'SELECT 1',
  'CREATE INDEX idx_vault_expiry ON vaults(status, expires_at)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  EXISTS(
    SELECT 1
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'files'
      AND index_name = 'idx_files_vault_status'
  ),
  'SELECT 1',
  'CREATE INDEX idx_files_vault_status ON files(vault_id, status, created_at)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  EXISTS(
    SELECT 1
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'files'
      AND index_name = 'idx_files_deleted_at'
  ),
  'SELECT 1',
  'CREATE INDEX idx_files_deleted_at ON files(deleted_at)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  EXISTS(
    SELECT 1
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'portfolio_entries'
      AND index_name = 'idx_portfolio_vault_owner_status'
  ),
  'SELECT 1',
  'CREATE INDEX idx_portfolio_vault_owner_status ON portfolio_entries(vault_id, owner_token_id, status, updated_at)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql = IF(
  EXISTS(
    SELECT 1
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'portfolio_entries'
      AND index_name = 'idx_portfolio_vault_status'
  ),
  'SELECT 1',
  'CREATE INDEX idx_portfolio_vault_status ON portfolio_entries(vault_id, status, updated_at)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Optional hard-fail trigger intentionally omitted from the portable setup script.
-- The submission's primary unauthorized-modification detection path is the
-- application-side integrity hash validation exposed through /api/security/unauthorized-check
-- and enforced on portfolio reads/updates. Some managed/local MySQL configurations
-- reject CREATE TRIGGER without elevated binary logging privileges, which would make
-- the setup script fail even though the assignment-facing tamper detection remains functional.
