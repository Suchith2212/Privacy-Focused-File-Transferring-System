# Database Evidence

This folder contains the packaged database-side proof for Module B. It shows that the schema, indexes, and tamper-detection model described in the report are present in the actual database state used for the submission.

## Packaged files

- `01_db_snapshot.txt`
- `02_schema_inventory.md`
- `07_tamper_before_check.txt`
- `08_tamper_detection_result.txt`

## What this evidence demonstrates

- `portfolio_entries` exists as the dedicated Module B CRUD table
- the relational schema includes the expected core and security tables
- the optimized indexes exist on the relevant tables
- `integrity_hash` is present on the portfolio table
- the tamper-detection workflow can identify direct database changes

## Useful SQL inspection commands

```sql
SHOW TABLES;
DESCRIBE portfolio_entries;
SHOW INDEX FROM portfolio_entries;
SHOW INDEX FROM inner_tokens;
SHOW INDEX FROM auth_attempts;
SHOW INDEX FROM download_logs;
SHOW INDEX FROM files;
SHOW INDEX FROM file_key_access;
SHOW INDEX FROM vaults;
SHOW INDEX FROM expiry_jobs;
SELECT entry_id, vault_id, owner_token_id, created_by_token_id, title, status, updated_at FROM portfolio_entries;
SELECT inner_token_id, vault_id, token_type, token_lookup_hash, status FROM inner_tokens;
SELECT file_id, vault_id, original_filename, status FROM files;
```

## How to read the packaged files

1. Open `01_db_snapshot.txt` for the concrete table/index snapshot
2. Open `02_schema_inventory.md` for the written explanation of what the tables and indexes mean
3. Open `07_tamper_before_check.txt` and `08_tamper_detection_result.txt` for the tamper-detection proof sequence
