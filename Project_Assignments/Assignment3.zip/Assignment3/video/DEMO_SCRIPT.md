﻿# Assignment 3 Demo Script (Short Video)

## Target Duration
8 to 12 minutes

## Segment 1: Setup and Scope (00:00 - 01:00)
1. Open `Assignment3/` directory and show structure (`module_a`, `module_b`, `evidence`, `report`, `video`).
2. State scope:
- Module A: transaction behavior + WAL recovery + ACID
- Module B: concurrency, race condition, failure simulation, stress

## Segment 2: Module A Architecture (01:00 - 03:00)
1. Open `module_a/engine/transactional_db.py`.
2. Explain:
- serialized transactions (`begin/commit/rollback`)
- WAL append for `BEGIN`, `OP`, `COMMIT`, `ROLLBACK`
- recovery logic that replays committed work and ignores incomplete transactions
3. Show WAL file path: `module_a/logs/acid_test_wal.log`.

## Segment 3: Module A ACID Proof (03:00 - 05:00)
Run commands:
```powershell
python module_a/tests/test_acid.py
python module_a/transaction_smoke_test.py
python module_a/smoke_test.py
```
Show terminal output and `evidence/MODULE_A_ACID_RESULTS.md`.

## Segment 4: Module B Concurrent and Stress Runs (05:00 - 07:00)
1. Show `module_b/concurrent_api_stress.py`.
2. Run/recap public load evidence (600 requests) and open:
- `evidence/module_b_public_load_summary.json`
- `evidence/MODULE_B_PUBLIC_LOAD_RESULT.md`
3. Run/recap authenticated load evidence and open:
- `evidence/module_b_auth_load_summary.json`
- `evidence/MODULE_B_AUTH_LOAD_RESULT.md`
- `evidence/MODULE_B_AUTH_PROFILE_COMPARISON.md`

## Segment 5: Race Condition and Failure Injection (07:00 - 09:00)
1. Show race test script: `module_b/race_condition_download_test.py`.
2. Show evidence:
- `evidence/race_condition_download_result.json`
- `evidence/RACE_CONDITION_DOWNLOAD_RESULT.md`
3. Show failure-injection script: `module_b/failure_injection_batch_atomicity_test.py`.
4. Show evidence:
- `evidence/failure_injection_batch_atomicity_result.json`
- `evidence/FAILURE_INJECTION_BATCH_ATOMICITY_RESULT.md`

## Segment 6: Final Summary (09:00 - 10:00)
1. Open `report/group_name_report.md` and summarize requirement coverage from the report sections.
2. Summarize:
- ACID in custom B+ Tree engine is validated
- concurrent API behavior and safeguards are observed
- race and failure paths show no incorrect partial state

## Notes for Final Video Export
- Keep all terminal commands visible.
- Keep backend running on `http://localhost:4000` during Module B demonstrations.
- Narrate each result immediately after showing evidence file.

