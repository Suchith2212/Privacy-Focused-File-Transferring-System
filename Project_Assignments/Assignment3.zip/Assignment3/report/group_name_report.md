# Assignment 3 Report -- Transaction Management and ACID Validation

**Course:** CS432 Database Systems | **Track:** 1 | **Team:** Dragons

| Field | Value |
|-------|-------|
| **Group Name** | Dragons |
| **Members** | Suchith (24110313), Hanook (24110378), Sanjay (24110030), Rohith (24110303), Rahul (24110285) |
| **GitHub** | https://github.com/Suchith2212/Privacy-Focused-File-Transferring-System |
| **Video Link** | `<enter_video_url_after_recording>` |
| **Submission Date** | April 5, 2026 |

---

## 1. Objective

This submission extends the custom B+ Tree database engine built in Assignment 2 with a
full **transaction management layer** satisfying all four ACID properties. The engine
uses zero external databases, ORMs, or pre-built transaction libraries. The only
storage backend is the custom B+ Tree from Assignment 2.

Two delivery modules are provided:

- **Module A** -- `TransactionalDatabaseManager` implementing `BEGIN / COMMIT / ROLLBACK`,
  Write-Ahead Logging (WAL) with `os.fsync()`, WAL-based crash recovery (commit
  replay + incomplete-transaction discard), and schema-plus-FK consistency enforcement
  across all seven GhostDrop domain relations.

- **Module B** -- Concurrent workload and stress-testing suite that empirically verifies
  ACID properties under thread-level contention, mid-commit failure injection,
  one-time-download race conditions, and 1,000+ operation mixed loads spanning all
  seven relations.

---

## 2. Architecture

### 2.1 Storage Layer

Each of the seven GhostDrop domain relations is stored in an independent B+ Tree
(order 4). No external storage is used.

```
vaults, inner_tokens, files, sessions, download_logs, expiry_jobs, portfolio_entries
    --> each backed by one BPlusTree instance
```

### 2.2 Transaction Lifecycle

When a caller begins a transaction, the engine:

1. **Acquires** a global `threading.RLock` (prevents concurrent writers).
2. **Assigns** a UUID transaction ID and **writes** a `BEGIN` record to the WAL.
3. **Buffers** each `insert / update / delete` as a `TxOperation` in memory,
   simultaneously writing an `OP` record to the WAL (durable immediately via `fsync`).
4. On **`commit()`**:
   - Runs full **validation** on a projected snapshot of the post-commit state:
     schema checks (field types, enums, required fields) and FK checks across all
     seven relations.
   - Writes a `PREPARE` record (validation fence).
   - Applies all operations atomically using an **undo-stack**: if any B+ Tree
     write fails, all prior writes in the same batch are reversed before re-raising.
   - Writes a `COMMIT` record and calls `os.fsync()`.
   - Releases the lock.
5. On **`rollback()`**: writes `ROLLBACK`, discards the buffer, releases the lock.
6. If `commit()` raises internally: writes `ROLLBACK reason=commit_failed`,
   replays the undo-stack to restore original B+ Tree state, re-raises the error.

### 2.3 Write-Ahead Log (WAL)

Implemented in `module_a/engine/wal.py`. Each record is one JSON line, flushed
to disk with `os.fsync()` before the method returns. Record types:

| Type | Key Fields | Purpose |
|------|------------|---------|
| `SCHEMA` | table, order | Recreate relation on recovery |
| `BEGIN` | tx_id | Mark transaction start |
| `OP` | tx_id, op, table, key, value | Log each staged mutation |
| `PREPARE` | tx_id | Pre-commit validation fence |
| `COMMIT` | tx_id | Durable commit marker |
| `ROLLBACK` | tx_id, reason | Abort marker |

**Write-ahead guarantee:** `OP` records exist in the WAL before any B+ Tree is
touched. A crash between `OP` and `COMMIT` leaves no `COMMIT` record, so recovery
discards the transaction.

### 2.4 Crash Recovery Algorithm

`_recover_from_wal()` runs automatically on startup:

```
1. Read WAL records in order.
2. SCHEMA -> recreate the relation.
3. BEGIN  -> open a pending buffer for that tx_id.
4. OP     -> append to the pending buffer.
5. ROLLBACK -> discard the pending buffer.
6. COMMIT   -> validate and replay the pending buffer into B+ Trees.
7. Any tx_id remaining in pending (no COMMIT seen) -> silently discarded.
```

Recovery never writes new WAL records. The same WAL can be replayed multiple
times with identical results (idempotent -- verified by Test 16).

### 2.5 Isolation and Locking

The engine implements **Strict Two-Phase Locking (S2PL)** via one global
`threading.RLock`:

- Lock acquired at `begin()`, held until `commit()` or `rollback()`.
- Non-transactional reads use `ReadOnlyTableView`, which acquires the same lock
  per read, guaranteeing committed-only visibility.
- This achieves the **Serializable** isolation level: no dirty reads, no lost
  updates, no phantoms, and a deterministic write-conflict order.

### 2.6 Consistency Enforcement

Two validation layers run at every commit against a full projected-state snapshot:

1. **Row schema** -- field types, required fields, status enum values.
2. **Cross-table FK integrity** -- all seven relations' foreign key rules checked
   before any B+ Tree is written. Any violation raises `ValueError` and writes
   `ROLLBACK reason=commit_failed` without touching storage.

---

## 3. Requirement-to-Evidence Matrix

| Requirement | Implementation | Evidence |
|---|---|---|
| Seven domain relations on B+ Tree | `module_a/engine/transactional_db.py` | `results/all_experiments_summary.json` |
| `BEGIN / COMMIT / ROLLBACK` | `TransactionalDatabaseManager` | `module_a/tests/test_acid.py` (16/16 PASS) |
| WAL append with `os.fsync()` | `module_a/engine/wal.py` | `logs/*.log` |
| Crash recovery | `_recover_from_wal()` | `results/durability_test_results.json` |
| Schema constraint enforcement | `_validate_row_schema()` | `results/consistency_test_results.json` |
| FK referential integrity | `_validate_cross_constraints()` | `results/consistency_test_results.json` |
| No dirty reads | `ReadOnlyTableView` + global `RLock` | `results/isolation_test_results.json` |
| No lost updates / write-conflict ordering | Strict 2PL serialization | Test 9: Isolation (serialized write conflict) |
| Mid-commit failure atomicity | undo-stack in `_apply_operations_atomically` | Test 3: Atomicity (mid-commit injection) |
| Incomplete-tail discarded on recovery | WAL replay model | Test 14: Durability (incomplete tail) |
| Idempotent recovery | Recovery does not modify WAL | Test 16: Recovery (idempotent replay) |
| WAL bypass destroys durability | Negative-path proof | Test 11 |
| Concurrent vault creation | `concurrent_vault_test.py` | `results/concurrent_vault_test.json` |
| One-time download race condition | `race_condition_download_test.py` | `results/race_condition_engine_result.json` |
| Failure injection (3 scenarios) | `failure_injection_test.py` | `results/failure_injection_results.json` |
| 1000+ op multi-relation stress test | `stress_test_runner.py` | `results/stress_test_metrics.json` |

---

## 4. Module A: ACID Test Suite (16/16 PASS)

```powershell
python module_a\tests\test_acid.py
```

| # | Test Name | Property | Result |
|---|-----------|----------|--------|
| 1 | Atomicity (crash before commit) | Atomicity | **PASS** |
| 2 | Atomicity (explicit rollback, 7 relations) | Atomicity | **PASS** |
| 3 | Atomicity (mid-commit failure injection rollback) | Atomicity | **PASS** |
| 4 | Consistency (valid references across 7 relations) | Consistency | **PASS** |
| 5 | Consistency (engine rejects negative file size) | Consistency | **PASS** |
| 6 | Consistency (engine rejects missing reference) | Consistency | **PASS** |
| 7 | Isolation (concurrent file inserts) | Isolation | **PASS** |
| 8 | Isolation (no dirty read) | Isolation | **PASS** |
| 9 | Isolation (serialized write conflict ordering) | Isolation | **PASS** |
| 10 | API blocks non-transactional mutations | Isolation / API | **PASS** |
| 11 | Negative path: bypass is not durable and not WAL-logged | Durability / API | **PASS** |
| 12 | Durability (single commit restart) | Durability | **PASS** |
| 13 | Durability (multiple commits restart across 7 relations) | Durability | **PASS** |
| 14 | Durability (multiple commits + incomplete tail) | Durability | **PASS** |
| 15 | Recovery (commit replay + incomplete ignore) | Recovery | **PASS** |
| 16 | Recovery (idempotent replay across repeated restarts) | Recovery | **PASS** |

```text
[OK] All 16 ACID/recovery checks passed.
[OK] Transaction + WAL + recovery smoke test passed.
[OK] Module A engine baseline smoke test passed.
```

### Significance of New Tests (Tests 3, 9, 11, 14, 16)

**Test 3 -- Mid-commit failure injection:**
Monkey-patches `_apply_operation_direct` to raise `RuntimeError` on the second
call. Verifies that the undo-stack reverses the first (already-applied) write
before re-raising. Without the undo-stack, the database would be left with only
half the transaction's changes, permanently.

**Test 9 -- Serialized write conflict ordering:**
T1 writes `file_size = 111`, T2 reads the committed value and writes 222. Final
value must be exactly 222 -- proving T2 never read a stale pre-T1 value (lost
update prevention).

**Test 11 -- WAL bypass negative proof:**
Direct B+ Tree insert bypasses the transaction manager. The row is visible in the
current process, but the WAL contains no `OP` record for it and recovery cannot
see it. After WAL recovery the row is absent. This proves the WAL boundary is
a real durability guarantee, not a convention.

**Test 14 -- Incomplete tail:**
Three committed transactions survive recovery. A fourth that staged operations
but never called `commit()` is cleanly discarded with no corruption.

**Test 16 -- Idempotent recovery:**
Two independent DB instances recover from the same WAL file. Both produce
identical state, and the WAL file is byte-for-byte unchanged after both recoveries.

---

## 5. ACID Experiments (1-4)

```powershell
python experiments\run_all_experiments.py
```

| Experiment | Scenarios | Outcome |
|---|---|---|
| 1 -- Atomicity | Crash-before-commit (3 tables) + explicit rollback (7 relations) | Both scenarios: all staged rows absent after recovery |
| 2 -- Consistency | Negative file size / missing vault FK / missing token FK / valid 7-relation commit | Violations raise `ValueError`; valid commit succeeds |
| 3 -- Isolation | 20 concurrent inserts / dirty-read guard / 50-thread lost-update prevention | 20/20 rows, dirty read returns null, final count = 50 |
| 4 -- Durability | 3 committed transactions + 1 staged/uncommitted across all 7 relations | All 7 committed rows survive; uncommitted row absent |

Evidence: `results/all_experiments_summary.json -> all_passed: true`

---

## 6. Module B: Concurrent and Stress Validation

```powershell
python module_b_stress_testing\concurrent_vault_test.py --users 20
python module_b_stress_testing\race_condition_download_test.py --concurrency 50
python module_b_stress_testing\failure_injection_test.py
python module_b_stress_testing\stress_test_runner.py --ops 1000
python module_b_stress_testing\acid_verification_suite.py
```

### Concurrent Vault Creation
20 concurrent threads each commit one atomic 3-table transaction
(vaults + inner_tokens + files). All 20 succeed with zero errors.

### Race Condition -- One-Time Download
50 threads simultaneously attempt to download a file with `max_downloads = 1`.
The S2PL lock serializes all attempts. Exactly one thread reads `download_count = 0`,
updates it to 1, and commits. The remaining 49 threads read `download_count = 1`
and raise `DownloadLimitExceeded`.

Result: `success = 1, failed = 49, final_download_count = 1`.

### Failure Injection (3 Scenarios)
- **Scenario A:** Injected `RuntimeError` after first op -- undo-stack reverts it.
- **Scenario B:** FK violation in a batch -- entire batch absent (all-or-nothing).
- **Scenario C:** Concurrent bad tx + good tx -- good tx commits, bad tx absent.

### Multi-Relation Stress Test (1,000 Operations)
Workload uses **FK-compliant multi-table transactions** across all 7 relations.

| Metric | Value |
|--------|-------|
| Total operations | 1,000 |
| Success rate | 100.00% |
| Throughput | 111.34 ops/sec |
| Latency mean | 8.974 ms |
| Latency p50 | 8.897 ms |
| Latency p95 | 13.640 ms |
| Latency p99 | 17.096 ms |
| Latency max | 61.972 ms |

The workload spans six operation types (`bundle_write`, `download_event`,
`expire_cycle`, `portfolio_write`, `cleanup`, `read_path`) -- all FK-compliant
and covering all seven domain relations.

---

## 7. End-to-End Grader Demo

```powershell
python run_demo.py --quick
```

```
  [PASS]  Module A - B+ Tree Smoke          0.09 s
  [PASS]  Module A - ACID Tests (16/16)     0.48 s
  [PASS]  Module A - WAL + Recovery Smoke   0.14 s
  [PASS]  ACID Experiments (1-4)            0.44 s
  [PASS]  Module B - Concurrent Vault       0.13 s
  [PASS]  Module B - Race Condition         0.11 s
  [PASS]  Module B - Failure Injection      0.05 s
  [PASS]  Module B - ACID Suite             0.20 s
  [DONE]  ALL STEPS PASSED - ACID properties fully validated!
  Total time: 1.63 s
```

---

## 8. Limitations

| Limitation | Reason | Impact |
|---|---|---|
| Global lock limits write parallelism | S2PL holds lock for full transaction duration | 111 ops/sec is sufficient for GhostDrop's low-concurrency workload |
| WAL grows unbounded (no checkpointing) | In-memory B+ Trees have no dirty-page concept | Experiment scripts reset WAL before running; total volume < 3 MB per grading session |
| Recovery replays from start of WAL | No checkpointing mechanism | Startup latency grows with WAL size; acceptable for assignment scope |
| Deadlock impossible by design | Single global lock eliminates lock-ordering cycles | No deadlock detection needed; row-level locking with deadlock detection is noted as future work |

---

## 9. Conclusion

This submission implements and empirically verifies all four ACID properties on a
pure-Python, B+ Tree-backed transaction engine with zero external database dependencies.

| Property | Mechanism | Evidence |
|---|---|---|
| Atomicity | WAL staging + undo-stack on partial failure | 3 tests (crash, rollback, mid-commit injection) |
| Consistency | Schema + FK validation on projected batch state | 3 tests (negative size, missing vault ref, missing token ref) |
| Isolation | Strict 2PL via global `RLock` + `ReadOnlyTableView` | 3 tests (concurrent inserts, no dirty read, write-conflict ordering) |
| Durability | `os.fsync()` on every WAL COMMIT; commit-replay on startup | 4 tests (single restart, 7-relation restart, incomplete tail, idempotent replay) |

All 16 Module A test cases pass. The grader demo completes in 1.63 seconds.
The stress test achieves 111.34 ops/sec at 100% success across 1,000 multi-relation
operations. The race condition test enforces the one-time-download invariant under
50 concurrent threads with exactly 1 success.
